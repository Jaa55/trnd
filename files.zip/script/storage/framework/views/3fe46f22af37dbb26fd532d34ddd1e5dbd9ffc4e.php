<?php $__env->startComponent('mail::message'); ?>
# Two Step Authentication

Here is 4-digit Verification Code:
<?php echo e($user->two_factor); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\newtong\script\resources\views/emails/verify.blade.php ENDPATH**/ ?>